import{R as o,i as d}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{o as RadarModule,d as createRadarServices};
