import{c as e,s as r}from"./flowDiagram-23GEKE2U-64f539cf.js";import{_ as a}from"./index-05a531f2.js";import"./chunk-5VM5RSS4-bd4223c1.js";import"./chunk-XXDRQBXY-9cc14509.js";import"./chunk-VR4S4FIN-e20e9c4d.js";import"./chunk-32BRIVSS-b00424de.js";var s=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),l=s,d=e({defaultLayout:"swimlane",styles:l});export{d as diagram};
