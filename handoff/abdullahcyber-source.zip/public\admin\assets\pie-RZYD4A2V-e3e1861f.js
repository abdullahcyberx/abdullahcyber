import{b as o,d as a}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{o as PieModule,a as createPieServices};
