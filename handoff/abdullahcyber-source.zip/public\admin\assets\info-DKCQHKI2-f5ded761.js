import{I as a,c}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{a as InfoModule,c as createInfoServices};
