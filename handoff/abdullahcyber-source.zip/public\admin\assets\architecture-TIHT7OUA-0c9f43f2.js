import{A as c,f as i}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{c as ArchitectureModule,i as createArchitectureServices};
