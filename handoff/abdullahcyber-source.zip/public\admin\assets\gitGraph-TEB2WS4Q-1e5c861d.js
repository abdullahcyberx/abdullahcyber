import{G as t,g as G}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{t as GitGraphModule,G as createGitGraphServices};
