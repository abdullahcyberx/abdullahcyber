export function gql(strings, ...args) {
  let str = "";
  strings.forEach((string, i) => {
    str += string + (args[i] || "");
  });
  return str;
}
export const SettingsPartsFragmentDoc = gql`
    fragment SettingsParts on Settings {
  __typename
  siteName
  domain
  brandText
  profile {
    __typename
    name
    alternateName
    jobTitle
    location
    email
    github
    linkedin
    cv
  }
  hero {
    __typename
    status
    eyebrow
    firstName
    lastName
    roles
    description
    primaryButton
    secondaryButton
  }
  about {
    __typename
    eyebrow
    headingLine1
    headingHighlight
    lead
    paragraphs
    quote
    focus
    approach
    educationShort
    contextTitle
    contextText
  }
  contact {
    __typename
    eyebrow
    headingLine1
    headingHighlight
    description
    formNote
  }
  footer {
    __typename
    tagline
  }
  seo {
    __typename
    title
    description
    keywords
    ogTitle
    ogDescription
    ogImage
  }
  security {
    __typename
    denialMessage
  }
}
    `;
export const ExperiencePartsFragmentDoc = gql`
    fragment ExperienceParts on Experience {
  __typename
  title
  organization
  location
  period
  type
  current
  order
  description
  skills
}
    `;
export const SkillPartsFragmentDoc = gql`
    fragment SkillParts on Skill {
  __typename
  title
  key
  keyLabel
  index
  description
  levelLabel
  percent
  order
  wide
  primary
}
    `;
export const ProjectPartsFragmentDoc = gql`
    fragment ProjectParts on Project {
  __typename
  title
  slug
  order
  featured
  artStyle
  meta
  description
  tools
  linkType
  externalUrl
  caseStudy {
    __typename
    label
    summary
    objective
    environment
    learning
    ethics
  }
}
    `;
export const CertificatePartsFragmentDoc = gql`
    fragment CertificateParts on Certificate {
  __typename
  title
  slug
  issuer
  displayDate
  credentialId
  featured
  order
  icon
  file
  verificationUrl
}
    `;
export const AchievementPartsFragmentDoc = gql`
    fragment AchievementParts on Achievement {
  __typename
  title
  shortTitle
  category
  order
}
    `;
export const EducationPartsFragmentDoc = gql`
    fragment EducationParts on Education {
  __typename
  degree
  institution
  expectedCompletion
  eyebrow
  extras {
    __typename
    title
    description
  }
}
    `;
export const AiPartsFragmentDoc = gql`
    fragment AiParts on Ai {
  __typename
  assistantName
  greeting
  unknown
  customFacts {
    __typename
    id
    patterns
    keywords
    answer
    source
  }
}
    `;
export const SettingsDocument = gql`
    query settings($relativePath: String!) {
  settings(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...SettingsParts
  }
}
    ${SettingsPartsFragmentDoc}`;
export const SettingsConnectionDocument = gql`
    query settingsConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: SettingsFilter) {
  settingsConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...SettingsParts
      }
    }
  }
}
    ${SettingsPartsFragmentDoc}`;
export const ExperienceDocument = gql`
    query experience($relativePath: String!) {
  experience(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...ExperienceParts
  }
}
    ${ExperiencePartsFragmentDoc}`;
export const ExperienceConnectionDocument = gql`
    query experienceConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: ExperienceFilter) {
  experienceConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...ExperienceParts
      }
    }
  }
}
    ${ExperiencePartsFragmentDoc}`;
export const SkillDocument = gql`
    query skill($relativePath: String!) {
  skill(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...SkillParts
  }
}
    ${SkillPartsFragmentDoc}`;
export const SkillConnectionDocument = gql`
    query skillConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: SkillFilter) {
  skillConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...SkillParts
      }
    }
  }
}
    ${SkillPartsFragmentDoc}`;
export const ProjectDocument = gql`
    query project($relativePath: String!) {
  project(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...ProjectParts
  }
}
    ${ProjectPartsFragmentDoc}`;
export const ProjectConnectionDocument = gql`
    query projectConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: ProjectFilter) {
  projectConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...ProjectParts
      }
    }
  }
}
    ${ProjectPartsFragmentDoc}`;
export const CertificateDocument = gql`
    query certificate($relativePath: String!) {
  certificate(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...CertificateParts
  }
}
    ${CertificatePartsFragmentDoc}`;
export const CertificateConnectionDocument = gql`
    query certificateConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: CertificateFilter) {
  certificateConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...CertificateParts
      }
    }
  }
}
    ${CertificatePartsFragmentDoc}`;
export const AchievementDocument = gql`
    query achievement($relativePath: String!) {
  achievement(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...AchievementParts
  }
}
    ${AchievementPartsFragmentDoc}`;
export const AchievementConnectionDocument = gql`
    query achievementConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: AchievementFilter) {
  achievementConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...AchievementParts
      }
    }
  }
}
    ${AchievementPartsFragmentDoc}`;
export const EducationDocument = gql`
    query education($relativePath: String!) {
  education(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...EducationParts
  }
}
    ${EducationPartsFragmentDoc}`;
export const EducationConnectionDocument = gql`
    query educationConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: EducationFilter) {
  educationConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...EducationParts
      }
    }
  }
}
    ${EducationPartsFragmentDoc}`;
export const AiDocument = gql`
    query ai($relativePath: String!) {
  ai(relativePath: $relativePath) {
    ... on Document {
      _sys {
        filename
        basename
        hasReferences
        breadcrumbs
        path
        relativePath
        extension
      }
      id
    }
    ...AiParts
  }
}
    ${AiPartsFragmentDoc}`;
export const AiConnectionDocument = gql`
    query aiConnection($before: String, $after: String, $first: Float, $last: Float, $sort: String, $filter: AiFilter) {
  aiConnection(
    before: $before
    after: $after
    first: $first
    last: $last
    sort: $sort
    filter: $filter
  ) {
    pageInfo {
      hasPreviousPage
      hasNextPage
      startCursor
      endCursor
    }
    totalCount
    edges {
      cursor
      node {
        ... on Document {
          _sys {
            filename
            basename
            hasReferences
            breadcrumbs
            path
            relativePath
            extension
          }
          id
        }
        ...AiParts
      }
    }
  }
}
    ${AiPartsFragmentDoc}`;
export function getSdk(requester) {
  return {
    settings(variables, options) {
      return requester(SettingsDocument, variables, options);
    },
    settingsConnection(variables, options) {
      return requester(SettingsConnectionDocument, variables, options);
    },
    experience(variables, options) {
      return requester(ExperienceDocument, variables, options);
    },
    experienceConnection(variables, options) {
      return requester(ExperienceConnectionDocument, variables, options);
    },
    skill(variables, options) {
      return requester(SkillDocument, variables, options);
    },
    skillConnection(variables, options) {
      return requester(SkillConnectionDocument, variables, options);
    },
    project(variables, options) {
      return requester(ProjectDocument, variables, options);
    },
    projectConnection(variables, options) {
      return requester(ProjectConnectionDocument, variables, options);
    },
    certificate(variables, options) {
      return requester(CertificateDocument, variables, options);
    },
    certificateConnection(variables, options) {
      return requester(CertificateConnectionDocument, variables, options);
    },
    achievement(variables, options) {
      return requester(AchievementDocument, variables, options);
    },
    achievementConnection(variables, options) {
      return requester(AchievementConnectionDocument, variables, options);
    },
    education(variables, options) {
      return requester(EducationDocument, variables, options);
    },
    educationConnection(variables, options) {
      return requester(EducationConnectionDocument, variables, options);
    },
    ai(variables, options) {
      return requester(AiDocument, variables, options);
    },
    aiConnection(variables, options) {
      return requester(AiConnectionDocument, variables, options);
    }
  };
}
import { createClient } from "tinacms/dist/client";
const generateRequester = (client) => {
  const requester = async (doc, vars, options) => {
    let url = client.apiUrl;
    if (options?.branch) {
      const index = client.apiUrl.lastIndexOf("/");
      url = client.apiUrl.substring(0, index + 1) + options.branch;
    }
    const data = await client.request({
      query: doc,
      variables: vars,
      url
    }, options);
    return { data: data?.data, errors: data?.errors, query: doc, variables: vars || {} };
  };
  return requester;
};
export const ExperimentalGetTinaClient = () => getSdk(
  generateRequester(
    createClient({
      url: "http://localhost:4001/graphql",
      queries
    })
  )
);
export const queries = (client) => {
  const requester = generateRequester(client);
  return getSdk(requester);
};
