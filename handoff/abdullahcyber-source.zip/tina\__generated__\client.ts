import { createClient } from "tinacms/dist/client";
import { queries } from "./types.js";
export const client = createClient({ cacheDir: 'C:/Users/Dell/Downloads/AbdullahCyber-TinaCMS-Secure-Admin/abdullahcyber-tinacms-secure/tina/__generated__/.cache/1783931736409', url: 'http://localhost:4001/graphql', token: 'undefined', queries,  });
export default client;
  