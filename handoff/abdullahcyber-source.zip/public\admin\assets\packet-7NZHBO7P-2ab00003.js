import{P as t,a as c}from"./mermaid-parser.core-57582cd9.js";import"./index-05a531f2.js";export{t as PacketModule,c as createPacketServices};
